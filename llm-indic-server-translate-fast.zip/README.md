---
title: Llm Indic Server Translate Fast
emoji: 👁
colorFrom: blue
colorTo: yellow
sdk: docker
pinned: false
license: mit
short_description: llm + translate
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
