
what is the capital of karnataka 
ಕರ್ನಾಟಕದ ರಾಜಧಾನಿ ಯಾವುದು?