export API_KEY=your-actual-key
export PORT=7860
export HOST=0.0.0.0
export SPEECH_RATE_LIMIT=5/minute
export CHAT_RATE_LIMIT=100/minute