from fastapi import FastAPI, Request, Depends, HTTPException
from contextlib import asynccontextmanager
import torch
from your_model_library import Model, Tokenizer  # Replace with actual imports

# Global variables for model and tokenizer
model = None
tokenizer = None
device = "cuda" if torch.cuda.is_available() else "cpu"  # Or specify your device

# Lifespan event to handle startup and shutdown
@asynccontextmanager
async def lifespan(app: FastAPI):
    global model, tokenizer
    # Initialize model and tokenizer at startup
    tokenizer = Tokenizer.from_pretrained("your-model-name")  # Replace with your tokenizer
    model = Model.from_pretrained("your-model-name")          # Replace with your model
    model.to(device).to(torch.bfloat16)                       # Move to device and set precision
    model.eval()                                              # Set to evaluation mode
    yield
    # Cleanup (optional) when the app shuts down
    del model, tokenizer
    torch.cuda.empty_cache() if torch.cuda.is_available() else None

app = FastAPI(lifespan=lifespan)

@app.post("/v1/chat", response_model=ChatResponse)
@limiter.limit(settings.chat_rate_limit)
async def chat(request: Request, chat_request: ChatRequest, api_key: str = Depends(get_api_key)):
    if not chat_request.prompt:
        raise HTTPException(status_code=400, detail="Prompt cannot be empty")
    logger.info(f"Received prompt: {chat_request.prompt}")
    try:
        messages = [
            [
                {"role": "system", "content": [{"type": "text", "text": "You are a helpful assistant."}]},
                {"role": "user", "content": [{"type": "text", "text": chat_request.prompt}]},
            ],
        ]
        # Prepare inputs (no need to move to device or change dtype, as model is already set)
        inputs = tokenizer.apply_chat_template(
            messages,
            add_generation_prompt=True,
            tokenize=True,
            return_dict=True,
            return_tensors="pt",
        ).to(device)  # Only move inputs to device, assuming model is already in bfloat16

        with torch.inference_mode():
            outputs = model.generate(**inputs, max_new_tokens=64)

        decoded_outputs = tokenizer.batch_decode(outputs, skip_special_tokens=True)
        response_text = decoded_outputs[0].split("model\n", 1)[1].strip() if "model\n" in decoded_outputs[0] else decoded_outputs[0].strip()
        logger.info(f"Chat Response: {response_text}")
        return ChatResponse(response=response_text)
    except Exception as e:
        logger.error(f"Error processing request: {str(e)}")
        raise HTTPException(status_code=500, detail=f"An error occurred: {str(e)}")