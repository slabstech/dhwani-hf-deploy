---
title: Tts Indic Server
emoji: 👁
colorFrom: green
colorTo: blue
sdk: docker
pinned: false
license: mit
short_description: Text To Speech for Indian Languages
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
