small

curl -X 'POST' \
  'https://gaganyatri-tts-indic-server.hf.space/v1/audio/speech' \
  -H 'accept: application/json' \
  -H 'Content-Type: application/json' \
  -d '{
  "input": "ನಿಮ್ಮ ಇನ್‌ಪುಟ್ ಪಠ್ಯವನ್ನು ಇಲ್ಲಿ ಸೇರಿಸಿ",
  "voice": "Anu speaks with a high pitch at a normal pace in a clear, close-sounding environment. Her neutral tone is captured with excellent audio quality",
  "model": "ai4bharat/indic-parler-tts",
  "response_format": "mp3",
  "speed": 1
}' -o test_small.mp3


Took 4.70 seconds to generate audio for 5 words

large -

curl -X 'POST' \
  'https://gaganyatri-tts-indic-server.hf.space/v1/audio/speech' \
  -H 'accept: application/json' \
  -H 'Content-Type: application/json' \
  -d '{
  "input": "ನಿಮ್ಮ ಇನ್‌ಪುಟ್ ಪಠ್ಯವನ್ನು ಇಲ್ಲಿ ಸೇರಿಸಿ, ನಮಸ್ಕಾರ, ಹೇಗಿದ್ದೀರಾ?, ಶುಭೋದಯ!, ಬೆಂಗಳೂರು ಕರ್ನಾಟಕ ರಾಜ್ಯದ ರಾಜಧಾನಿ ಆಗಿದೆ ಕರ್ನಾಟಕದಲ್ಲಿ ನಾವು ಕನ್ನಡ ಮಾತನಾಡುತ್ತೇವೆ , ಕರ್ನಾಟಕದ ರಾಜಧಾನಿ ಯಾವುದು",
  "voice": "Anu speaks with a high pitch at a normal pace in a clear, close-sounding environment. Her neutral tone is captured with excellent audio quality",
  "model": "ai4bharat/indic-parler-tts",
  "response_format": "mp3",
  "speed": 1
}' -o test_large.mp3



Simple Transformer on T4 
Took 4.70 seconds to generate audio for 5 words

Took 23.63 seconds to generate audio for 21 words 


Flash attention on T4

FA - 2025-03-16 17:52:55,225 - tts_indic_server - INFO - Took 8.16 seconds to generate audio for 5 words using 0

FA - 2025-03-16 17:53:59,147 - tts_indic_server - INFO - Took 38.29 seconds to generate audio for 21 words using 0


Flash attention on L4 server

2025-03-16 18:01:14,297 - tts_indic_server - INFO - Took 3.99 seconds to generate audio for 5 words using 0

2025-03-16 18:00:58,528 - tts_indic_server - INFO - Took 20.82 seconds to generate audio for 21 words using 0

APP - request
2025-03-16 18:02:50,117 - tts_indic_server - INFO - Took 7.92 seconds to generate audio for 7 words using 0


Flash Attention on A10 G server
2025-03-16 18:10:53,413 - tts_indic_server - INFO - Took 25.52 seconds to generate audio for 21 words using 0
2025-03-16 18:11:22,699 - tts_indic_server - INFO - Took 24.33 seconds to generate audio for 21 words using 0


Torch Compile - regular- 

2025-03-16 18:46:14,854 - tts_indic_server - INFO - Took 12.10 seconds to generate audio for 21 words using CUDA:0
INFO:     10.20.28.164:22507 - "POST /v1/audio/speech HTTP/1.1" 200 OK
2025-03-16 18:47:05,304 - tts_indic_server - INFO - Took 11.99 seconds to generate audio for 21 words using CUDA:0
INFO:     10.20.34.20:1097 - "POST /v1/audio/speech HTTP/1.1" 200 OK
2025-03-16 18:47:36,929 - tts_indic_server - INFO - Took 2.58 seconds to generate audio for 5 words using CUDA:0
INFO:     10.20.28.164:62426 - "POST /v1/audio/speech HTTP/1.1" 200 OK
2025-03-16 18:47:59,388 - tts_indic_server - INFO - Took 10.65 seconds to generate audio for 21 words using CUDA:0
INFO:     10.20.28.164:21051 - "POST /v1/audio/speech HTTP/1.1" 200 OK
2025-03-16 18:48:50,432 - tts_indic_server - INFO - Took 4.70 seconds to generate audio for 7 words using CUDA:0
INFO:     10.20.34.20:33417 - "POST /v1/audio/speech HTTP/1.1" 200 OK
2025-03-16 18:49:16,366 - tts_indic_server - INFO - Took 2.72 seconds to generate audio for 1 words using CUDA:0
INFO:     10.20.34.20:4572 - "POST /v1/audio/speech HTTP/1.1" 200 OK
2025-03-16 18:49:49,739 - tts_indic_server - INFO - Took 13.51 seconds to generate audio for 21 words using CUDA:0


