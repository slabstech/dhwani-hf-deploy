import torch
from parler_tts import ParlerTTSForConditionalGeneration
from transformers import AutoTokenizer
import soundfile as sf
import time

# Set device to CUDA if available, otherwise CPU
device = "cuda:0" if torch.cuda.is_available() else "cpu"

# Model configuration
model_name = "ai4bharat/indic-parler-tts"
attn_implementation = "flash_attention_2"  # Options: "sdpa" or "flash_attention_2"
torch_dtype = torch.bfloat16

# Load the model with specified attention implementation and dtype
model = ParlerTTSForConditionalGeneration.from_pretrained(
    model_name,
    attn_implementation=attn_implementation
).to(device, dtype=torch_dtype)

# Load tokenizers
tokenizer = AutoTokenizer.from_pretrained("ai4bharat/indic-parler-tts")
description_tokenizer = AutoTokenizer.from_pretrained(model.config.text_encoder._name_or_path)

# Input prompts (in Kannada)
prompt = "ನಿಮ್ಮ ಇನ್‌ಪುಟ್ ಪಠ್ಯವನ್ನು ಇಲ್ಲಿ ಸೇರಿಸಿ, ಸಾಮ್ರಾಜ್ಯದಲ್ಲಿ ಅತ್ಯುನ್ನತಸ್ಥಾನವನ್ನು ಗಳಿಸಿದೆ."
prompt_2 = (
    "ನಿಮ್ಮ ಇನ್‌ಪುಟ್ ಪಠ್ಯವನ್ನು ಇಲ್ಲಿ ಸೇರಿಸಿ, ಸಾಮ್ರಾಜ್ಯದಲ್ಲಿ ಅತ್ಯುನ್ನತಸ್ಥಾನವನ್ನು ಗಳಿಸಿದೆ. "
    "ಇದರ ಕರ್ತೃವಿಗೆ ಆದಿಕವಿ ಆ ಎಂದೂ ಸಾರ್ಧಕವಾದ ವಿಶೇಷಣಗಳು ಬರಾಲಾ ಪ್ರಸಿದ್ಧಿಗೆ ಇಲ್ಲಿನ ಬಂದಿವೆ. "
    "ಶ್ರೇಯಸ್ಸಿನ ಸಂಪಾದನೆಗೂ ನಂಬಿಕೆಯಾಗಿದೆ. ಸೀತಾ, ಕಧಾವಸ್ತುವು ರಸಜ್ಞ್ಞ ತೆಯನ್ನು ಸಹೃದಯನ  "
    "ಭಾರತದ ಸಹಾಚು ಇವದ್ಮಡಿಸುವುದಲ್ಲದೆ, ಜನರೆಲ್ಲರ ಆತನ ನ್ಯಾಯವಾದ್‌ ವಾಲ್ಮೀಕಿಮಹರ್ಷಿಗಳಂ ಈ ಮಹಾಕಾವ್ಯದಲ್ಲಿ"
)

# Description of the voice
description = (
    "Anu speaks with a high pitch at a normal pace in a clear, close-sounding environment. "
    "Her neutral tone is captured with excellent audio quality"
)

# Start timing
start = time.perf_counter()

# Tokenize the description and prompt
description_input_ids = description_tokenizer(description, return_tensors="pt").to(device)
prompt_input_ids = tokenizer(prompt, return_tensors="pt").to(device)

# Generate audio
generation = model.generate(
    input_ids=description_input_ids.input_ids,
    attention_mask=description_input_ids.attention_mask,
    prompt_input_ids=prompt_input_ids.input_ids,
    prompt_attention_mask=prompt_input_ids.attention_mask
)

# Convert bfloat16 tensor to float32, then to NumPy array
audio_arr = generation.cpu().float().numpy().squeeze()

# Write the audio to a WAV file
sf.write("flash_attention_tts.wav", audio_arr, model.config.sampling_rate)

# Print the time taken and word count
print(f"Took {time.perf_counter() - start:.2f} seconds to generate audio for {len(prompt.split())} words")