---
title: Translate Indic Server Cpu
emoji: 📚
colorFrom: purple
colorTo: pink
sdk: docker
pinned: false
license: mit
short_description: Translation API for Indian Languages
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
