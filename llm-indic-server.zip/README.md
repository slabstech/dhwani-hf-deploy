---
title: Llm Indic Server
emoji: 📈
colorFrom: yellow
colorTo: pink
sdk: docker
pinned: false
license: mit
short_description: LLM for Indian Languages
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
