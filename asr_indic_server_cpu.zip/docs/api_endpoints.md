API endpoints

- sarvam batch ASR - https://github.com/sarvamai/sarvam-ai-cookbook/blob/main/notebooks/stt/stt-batch-api/Sarvam_STT_Batch_API_Demo.ipynb