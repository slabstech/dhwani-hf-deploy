Load Test API


- pip instal locust
- cd src/test
- locust --host localhost:8000 --run-time 60