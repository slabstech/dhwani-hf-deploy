---
title: Asr Indic Server Cpu
emoji: 📚
colorFrom: indigo
colorTo: yellow
sdk: docker
pinned: false
license: mit
short_description: ASR INDIC Server for CPU
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
